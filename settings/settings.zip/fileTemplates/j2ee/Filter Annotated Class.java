#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
@javax.servlet.annotation.WebFilter("/*")
public class ${Class_Name} implements javax.servlet.Filter {
    public void doFilter(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response, javax.servlet.FilterChain chain) throws javax.servlet.ServletException, java.io.IOException {
        var req = (javax.servlet.http.HttpServletRequest) request;
        var resp = (javax.servlet.http.HttpServletResponse) response;
        
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        java.io.PrintWriter out = resp.getWriter();
        javax.servlet.http.HttpSession session = req.getSession();
       
        chain.doFilter(req, resp);
    }
}
