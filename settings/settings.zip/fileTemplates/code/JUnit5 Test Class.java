public class ${NAME} {
    @Test
    public void test() {
        
    }
}